#include <iostream>
using namespace std;
main(){
int n1,n2,n3;
cout<<"Enter a number :";
cin>>n1;
cout<<"Enter 2nd number :";
cin>>n2;
n3=n1+n2;
cout<<"Your ans is .. : "<<n3;






}